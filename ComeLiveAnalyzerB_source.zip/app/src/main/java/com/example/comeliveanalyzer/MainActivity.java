package com.example.comeliveanalyzer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE = 5101;
    private TextView status, stats, history;
    private MediaProjection projection;
    private ImageReader imageReader;
    private android.hardware.display.VirtualDisplay virtualDisplay;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayList<String> rows = new ArrayList<>();
    private int redCount = 0, greenCount = 0, violetCount = 0, otherCount = 0;
    private boolean scanning = false;
    private long lastSampleAt = 0;
    private int screenWidth, screenHeight, screenDensity;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(dm);
        screenWidth = dm.widthPixels;
        screenHeight = dm.heightPixels;
        screenDensity = dm.densityDpi;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 28, 24, 20);
        root.setBackgroundColor(0xFFF8FAFC);

        TextView title = new TextView(this);
        title.setText("Come Live Color Analyzer B");
        title.setTextSize(23);
        title.setTextColor(0xFF111827);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView note = new TextView(this);
        note.setText("Scans visible screen colors only. It cannot predict or guarantee the next result.");
        note.setTextSize(14);
        note.setTextColor(0xFF475569);
        note.setPadding(0, 14, 0, 14);
        root.addView(note);

        status = new TextView(this);
        status.setText("Status: Not scanning");
        status.setTextSize(16);
        root.addView(status);

        Button start = new Button(this);
        start.setText("Start Live Screen Scan");
        root.addView(start);
        start.setOnClickListener(v -> {
            MediaProjectionManager mpm = (MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            startActivityForResult(mpm.createScreenCaptureIntent(), REQUEST_CAPTURE);
        });

        Button stop = new Button(this);
        stop.setText("Stop Scan");
        root.addView(stop);
        stop.setOnClickListener(v -> stopScan());

        stats = new TextView(this);
        stats.setTextSize(16);
        stats.setTextColor(0xFF111827);
        stats.setPadding(0, 18, 0, 12);
        root.addView(stats);

        TextView histTitle = new TextView(this);
        histTitle.setText("Detected color history");
        histTitle.setTextSize(18);
        histTitle.setTextColor(0xFF111827);
        root.addView(histTitle);

        history = new TextView(this);
        history.setTextSize(14);
        history.setTextColor(0xFF334155);
        ScrollView scroller = new ScrollView(this);
        scroller.addView(history);
        root.addView(scroller, new LinearLayout.LayoutParams(-1, 0, 1));

        Button clear = new Button(this);
        clear.setText("Clear History");
        root.addView(clear);
        clear.setOnClickListener(v -> {
            rows.clear(); redCount=0; greenCount=0; violetCount=0; otherCount=0;
            updateText();
        });

        setContentView(root);
        updateText();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                MediaProjectionManager mpm = (MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
                projection = mpm.getMediaProjection(resultCode, data);
                beginCapture();
            } else {
                Toast.makeText(this, "Screen capture permission was not granted.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void beginCapture() {
        try {
            imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2);
            virtualDisplay = projection.createVirtualDisplay("ComeLiveAnalyzer",
                    screenWidth, screenHeight, screenDensity,
                    android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    imageReader.getSurface(), null, handler);
            scanning = true;
            status.setText("Status: Scanning screen (sampled periodically)");
            handler.postDelayed(sampleTask, 1000);
        } catch (Exception e) {
            status.setText("Could not start capture: " + e.getMessage());
            stopScan();
        }
    }

    private final Runnable sampleTask = new Runnable() {
        @Override public void run() {
            if (!scanning || imageReader == null) return;
            Image img = null;
            try {
                img = imageReader.acquireLatestImage();
                if (img != null) {
                    Image.Plane plane = img.getPlanes()[0];
                    ByteBuffer buffer = plane.getBuffer();
                    int pixelStride = plane.getPixelStride();
                    int rowStride = plane.getRowStride();
                    int rowPadding = rowStride - pixelStride * screenWidth;
                    Bitmap bitmap = Bitmap.createBitmap(screenWidth + rowPadding / pixelStride,
                            screenHeight, Bitmap.Config.ARGB_8888);
                    bitmap.copyPixelsFromBuffer(buffer);
                    Bitmap cropped = Bitmap.createBitmap(bitmap, 0, 0, screenWidth, screenHeight);
                    String color = estimateDominantColor(cropped);
                    bitmap.recycle(); cropped.recycle();
                    if (color != null) addResult(color);
                }
            } catch (Exception ignored) {
                // A screen can change while the capture is being read; try the next sample.
            } finally {
                if (img != null) img.close();
            }
            if (scanning) handler.postDelayed(this, 1200);
        }
    };

    // Approximate whole-screen color sampling; this is not OCR and does not identify game results.
    private String estimateDominantColor(Bitmap bmp) {
        int r=0,g=0,b=0,n=0;
        int stepX = Math.max(1, bmp.getWidth()/80);
        int stepY = Math.max(1, bmp.getHeight()/120);
        for (int y=0; y<bmp.getHeight(); y+=stepY) {
            for (int x=0; x<bmp.getWidth(); x+=stepX) {
                int c = bmp.getPixel(x,y);
                int rr=(c>>16)&255, gg=(c>>8)&255, bb=c&255;
                // Ignore near-white and near-black UI/background pixels.
                int max=Math.max(rr, Math.max(gg,bb)), min=Math.min(rr,Math.min(gg,bb));
                if (max-min < 35 || max < 60) continue;
                r+=rr; g+=gg; b+=bb; n++;
            }
        }
        if (n == 0) return "Unclear";
        r/=n; g/=n; b/=n;
        if (r > g*1.25 && r > b*1.2) return "Red (approx.)";
        if (g > r*1.15 && g > b*1.15) return "Green (approx.)";
        if (b > r*1.1 && r > g*1.1) return "Violet/Blue (approx.)";
        return "Mixed/Other";
    }

    private void addResult(String color) {
        if (color.startsWith("Red")) redCount++;
        else if (color.startsWith("Green")) greenCount++;
        else if (color.startsWith("Violet")) violetCount++;
        else otherCount++;
        String time = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
        rows.add(0, time + " — " + color);
        while (rows.size() > 100) rows.remove(rows.size()-1);
        updateText();
    }

    private void updateText() {
        int total = redCount+greenCount+violetCount+otherCount;
        stats.setText("Samples: " + total + "\\nRed: " + redCount + " | Green: " + greenCount
                + " | Violet/Blue: " + violetCount + " | Other: " + otherCount
                + "\\nThese are approximate screen-wide samples, not game-result predictions.");
        StringBuilder sb = new StringBuilder();
        for (String row : rows) sb.append("• ").append(row).append("\\n");
        history.setText(sb.length()==0 ? "No samples yet." : sb.toString());
    }

    private void stopScan() {
        scanning = false;
        handler.removeCallbacks(sampleTask);
        if (virtualDisplay != null) { virtualDisplay.release(); virtualDisplay = null; }
        if (imageReader != null) { imageReader.close(); imageReader = null; }
        if (projection != null) { projection.stop(); projection = null; }
        if (status != null) status.setText("Status: Not scanning");
    }

    @Override protected void onDestroy() {
        stopScan();
        super.onDestroy();
    }
}
